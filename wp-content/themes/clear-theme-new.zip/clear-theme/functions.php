<?php
/**
 * @package Clear_Theme
 */

    require get_template_directory() . '/includes/styles-and-scripts.php';
    require get_template_directory() . '/includes/widget-setting.php';
    require get_template_directory() . '/includes/theme-support.php';
    require get_template_directory() . '/includes/custom-post-type.php';
