<?php
function post_type_casino() {
    $labels = [
        'name' => __( 'Casino' ),
        'singular_name' => __( 'Casino' ),
        'add_new' => __( 'New Casino' ),
        'add_new_item' => __( 'Add New Casino' ),
        'edit_item' => __( 'Edit Casino' ),
        'new_item' => __( 'New Casino' ),
        'view_item' => __( 'View Casino' ),
        'search_items' => __( 'Search Casino' ),
        'not_found' =>  __( 'No Casino Found' ),
        'not_found_in_trash' => __( 'No Casino found in Trash' ),
    ];
    $args = [
        'publicly_queryable' => true,
        'labels' => $labels,
        'has_archive' => false,
        'public' => true,
        'hierarchical' => false,
        'menu_position' => 5,
        'supports' => [
            'title',
            'editor',
            'custom-fields',
            'thumbnail'
        ],
    ];
    register_post_type( 'casino', $args );
}
add_action( 'init', 'post_type_casino' );
