<?php
function clear_theme_setup() {
    add_theme_support( 'post-thumbnails' );
    register_nav_menus(
        array(
            'Main Menu'    => esc_html__( 'Primary', 'clear-theme' ),
        )
    );
    add_theme_support(
        'html5',
        array(
            'search-form',
            'comment-form',
            'comment-list',
            'gallery',
            'caption',
            'style',
            'script',
        )
    );
    add_theme_support(
        'custom-logo',
        array(
            'height'      => 250,
            'width'       => 250,
            'flex-width'  => true,
            'flex-height' => true,
        )
    );
}
add_action( 'after_setup_theme', 'clear_theme_setup' );

function remove_editor() {
    if (isset($_GET['post'])) {
        $id = $_GET['post'];
        $template = get_post_meta($id, '_wp_page_template', true);
        switch ($template) {
            case 'template/scheme-items.php':
                remove_post_type_support('page', 'editor');
                break;
            default :
                break;
        }
    }
}
add_action('init', 'remove_editor');