<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Clear_Theme
 */

?>
    </main>
	<footer class="lp-footer">
        <div class="container">
            <div class="lp-footer__wrapper">
                <div class="lp-footer__row">
                    <h2><?php bloginfo( 'name' ); ?></h2>
                </div>
                <div class="lp-footer__row">
                    <div class="lp-footer__col">
                        <a href="https://casibom.work/" target="_blank" rel="noopener">Casibom</a>
                    </div>
                    <div class="lp-footer__col">
                        <a id="ButtonTop" href="#">Back to top</a>
                    </div>
                </div>
            </div>
        </div>
	</footer>

<?php wp_footer(); ?>

</body>
</html>
