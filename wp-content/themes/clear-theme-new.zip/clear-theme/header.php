<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Clear_Theme
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<div class="wrapper"></div>
<header class="lp-header">
    <div class="container">
        <div class="lp-header__wrapper">
            <div class="lp-header__row">
                <div class="lp-header__col">
                    <div id="burger-menu" class="burger-menu">
                        <span></span>
                    </div>
                    <div class="lp-header-nav__wrapper">
                        <div class="lp-header-nav__content">
                            ssss
                        </div>
                        <nav class="lp-header-nav">
                            <?php
                            wp_nav_menu (
                                [
                                    'theme_location' => 'Main Menu',
                                    'menu_id'        => 'primary-menu',
                                ]
                            );
                            ?>
                        </nav>
                    </div>
                </div>
                <div class="lp-header__col">
                    <div class="lp-header__logo">
                        <?php if( has_custom_logo() ):  ?>
                            <?php
                                $custom_logo_id = get_theme_mod( 'custom_logo' );
                                $custom_logo_data = wp_get_attachment_image_src( $custom_logo_id , 'full' );
                                $custom_logo_url = $custom_logo_data[0];
                            ?>

                            <a href="<?= esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" rel="home">
                                <img src="<?= esc_url( $custom_logo_url ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>"/>
                            </a>
                        <?php else: ?>
                            <div class="site-name"><?php bloginfo( 'name' ); ?></div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="lp-header__col">
                    <?php get_search_form(); ?>
                    <div class="language">
                        <span class="head">En</span>
                    </div>
                </div>

            </div>
        </div>
    </div>
</header>
<main>
