<section class="si-promo">
    <h1 class="title si-title"><?php the_title(); ?></h1>
    <div class="si-promo__wrapper">
        <div class="si-promo__row">
            <div class="si-promo__col">
                <div class="si-promo__col-title"></div>
                <div class="si-promo__item">
                    <div class="si-promo__item--icon"></div>
                    <div class="si-promo__item--content">
                        <div class="si-promo__item--title"></div>
                        <div class="si-promo__item--subtitle"></div>
                    </div>
                </div>
            </div>
            <div class="si-promo__col"></div>
        </div>
    </div>
</section>
