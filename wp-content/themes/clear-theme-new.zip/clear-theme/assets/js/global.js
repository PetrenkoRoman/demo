jQuery(document).ready(function($) {
    $(function () {
        $('#ButtonTop').click(function () {
            $('html, body').animate({
                    scrollTop: '0px'
                },
                1000);
            return false;
        });
    });

    $("#burger-menu").click(function(){
        $(".lp-header-nav__wrapper").toggleClass("lp-header-nav__wrapper--active");
        $("body").toggleClass("overflow");
        $(".wrapper").toggleClass("wrapper-active");
    });










});


