<?php
function clear_theme_scripts() {
    wp_enqueue_style( 'stylesheet', get_stylesheet_uri() );

    if( is_page_template( 'template/scheme-items.php' ) ) {
        wp_enqueue_style('scheme-items', get_template_directory_uri() . '/assets/css/template/scheme-items.css', ['stylesheet']);
    }
}
add_action( 'wp_enqueue_scripts', 'clear_theme_scripts' );
