<section class="breadcrumbs">
    <ul class="breadcrumbs__list">
        <li class="breadcrumbs__item">home</li>
        <li class="breadcrumbs__item"><span class="breadcrumbs__item-arrow"><</span></li>
        <li class="breadcrumbs__item">company</li>
        <li class="breadcrumbs__item"><span class="breadcrumbs__item-arrow"><</span></li>
        <li class="breadcrumbs__item">AI-first Softdev company</li>
    </ul>
</section>