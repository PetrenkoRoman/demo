<section class="pagination">
    <div class="pagination__wrapper">
        <a href="#" class="btn btn-border-blue pagination-prev"></a>
        <ul class="pagination-list">
            <li class="pagination-item"><a href="#" class="pagination-link">01</a></li>
            <li class="pagination-item"><a href="#" class="pagination-link pagination-link__active">02</a></li>
            <li class="pagination-item"><a href="#" class="pagination-link">03</a></li>
            <li class="pagination-item"><a href="#" class="pagination-link">04</a></li>
            <li class="pagination-item"><a href="#" class="pagination-link">05</a></li>
            <li class="pagination-item"><a href="#" class="pagination-link">06</a></li>
            <li class="pagination-item"><a href="#" class="pagination-link">07</a></li>
            <li class="pagination-item"><a href="#" class="pagination-link">08</a></li>
            <li class="pagination-item">...</li>
            <li class="pagination-item"><a href="#" class="pagination-link">100</a></li>
        </ul>
        <a href="#" class="btn btn-border-blue pagination-next"></a>
    </div>
</section>