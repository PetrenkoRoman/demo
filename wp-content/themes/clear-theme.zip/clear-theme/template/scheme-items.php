<?php
/* Template Name: Scheme Items */
get_header();
?>
<div class="si-template">
    <div class="container">
        <div class="si-wrapper">
            <?php get_template_part('template-parts/breadcrumbs');?>
            <?php get_template_part('template-parts/scheme-items/section-promo');?>
            <?php get_template_part('template-parts/pagination');?>
        </div>
    </div>
</div>
<?php get_footer(); ?>